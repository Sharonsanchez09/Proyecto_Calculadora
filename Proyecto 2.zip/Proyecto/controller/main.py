from view import terminal

def iniciar_aplicacion():
    terminal.mostrar_menu()

if __name__ == "__main__":
    iniciar_aplicacion()